import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-RJ5UVYRR.js";
import "./chunk-TUQDQINQ.js";
import "./chunk-UQJ46ZO3.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-S3ZCYKHL.js";
import "./chunk-AIEYJCOW.js";
import "./chunk-M3ZRBVYP.js";
import "./chunk-ML65ZJ4N.js";
import "./chunk-PHKHADS4.js";
import "./chunk-TTGZJSVO.js";
import "./chunk-GOMI4DH3.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
