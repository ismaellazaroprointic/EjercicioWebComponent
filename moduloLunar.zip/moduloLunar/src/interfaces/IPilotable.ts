export interface IPilotable {

    dameIdentificador(): string;
    dameNombreCompleto(): string;
    dameEdad(): number;
}